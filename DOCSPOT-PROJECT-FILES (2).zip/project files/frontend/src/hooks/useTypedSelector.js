import { useSelector } from "react-redux";

const useTypedSelector = useSelector;

export default useTypedSelector;
