// Nothing needed here — reference types are only for TypeScript
